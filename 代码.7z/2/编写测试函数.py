# # ！/usr/bin/python3
# -*- coding: utf-8 -*-
# 当前项目名称：python_基础教程
# 文件名称： 编写测试函数
# 登录用户名： yanshaoyou
# 作者： 闫少友
# 邮件： 2395969839@qq.com
# 电话：17855503800
# 创建时间： 2021/10/12  9:43

# 2.1 目录结构
# tasks_proj/
#  |——CHANGELOG.rst
#  |——LICENSE
#  |——MANIFEST.in
#  |——README.rst
#  |——setup.py
#  |——src                （放源码）
#  |       |——tasks
#  |       |——__init__.py
#  |       |——api.py
#  |       |——cli.py
#  |       |——config.py
#  |       |——tasksdb_pymongo.py
#  |       |——taskdb_tinydb.py
#  |——tests                （放测试）
#          |——conftest.py
#          |——pytest.ini
#          |——func
#                  |——__init__.py
#                  |——test_add.py
#                  |——。。。
#          |——unit
#                  |——_init__.py
#                  |——test_task.py
#                  |。。。
# README文件告诉用户如何使用你的包；
# LICENSE文件放许可条文
# CHANGELOG.rst文件放变更记录，编写风格可阅读https://keepachngelog.com
# MANIFEST.in:清单
# src/__init__.py:告诉python解释器该目录是Python包，以及在里面设置导入函数的操作，使其它调用函数更方便。
# tests/__init__.py:空文件，给pytest提供搜索路径，以及pytest.ini文件。
# pytest.ini：保存pytest在该项目下的特定配置。
# conftest.py：pytest的“本地插件库”，包含hook函数和fixture；同一项目内可以有多个conftest文件。

# 2.2 assert声明

# 2.3 测试异常的格式 with pytest.raises(<expected exception>)
# 上面的测试中只检验了传参数据的 “类型异常”，换可以检验 “值异常”。
# 为校验异常信息是否符合预期，可以通过增加 as excinfo 语句得到异常消息的值，再进行比对。
# import pytest
# import tasks
#
# def test_add_raises():
#     """add() should raise an exception with wrong type param"""
#     with pytest.raises(AttributeError) as excinfo:
#         tasks.add(task="not a Task object")
#     exception_msg = excinfo.value.args[0]    # 获得报错信息
#     assert exception_msg == "module 'tasks' has no attribute 'add'"

# 2.4 pytest 允许使用 marker 对测试函数做标记
# 警告信息消除，mark标记时会warn，可以在conftest里面添加。
# def pytest_configure(config):
#     marker_list = ["search","login"]
#     for markers in marker_list:
#         config.addinivalue_line("markers",markers)

# 2.5 skip 和 skipif 允许你跳过不希望运行的测试。
# @pytest.mark.skip(reason="跳过的原因")
# @pytest.mark.skipif(表达式,reason="跳过的原因")
# 如果运行的时候要看到跳过的原因，可以使用 -r
# -r选项后面要紧接以下的一个参数，用于过滤显示测试用例的结果。
# f：失败的
# E：出错的
# s：跳过执行的
# x：跳过执行，并标记为xfailed的
# X：跳过执行，并标记为xpassed的
# p：测试通过的
# P：测试通过，并且有输出信息的；即用例中有print等
# a：除了测试通过的，其他所有的；即除了p和P的
# A：所有的
# 上述字符参数可以叠加使用，例如：我们期望过滤出失败的和未执行的：
# pytest -rfs

# 2.6 xfail标记预期会失败的;@pytest.mark.xfail();可以添加表达式限定，原因说明；reason=“描述”。

# 2.7 -k 选项允许用一个表达式指定需要运行的测试，该表达式可以匹配测试名（或其子串）。
# 表达式中可以包含and 、or 、not，运行所有名字中包含 _raises 的测试。
# pytest -k _raises

# 2.8 参数化测试；简单的说可以一次批量对多组数据进行测试
# @pytest.mark.parametrize() 的第一个参数是用逗号分隔的字符串列表；第二个参数是一个值列表。
# pytest会轮流对每个task做测试，并分别报告每一个测试用例的结果。

# @pytest.mark.parametrize() 装饰器也可以给测试类加上，在这种情况下，该数据集会被传递给该类的所有类方法。

# 在给@pytest.mark.parametrize() 装饰器传入列表参数时，还可以在参数值旁边定义一个 id 来做标识，
# 语法是 pytest.param(<value>,id="something")
# 参数组合
# 方法作为参数名

# 使用一个值标识要测试的数值数据，在使用一个id来标记元素，最后使用parametrize（。。。，ids=。）来标记。
# 这种方法解耦，推荐使用。
# 装饰器放在函数、类的前面不空行。

