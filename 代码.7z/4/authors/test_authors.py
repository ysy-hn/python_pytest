import json


def test_brian_in_portland(author_file_json):
    with author_file_json.open() as f:
        authors = json.load(f)
    assert authors['Brian']['City'] == 'Portland'


def test_all_have_cities(author_file_json):
    with author_file_json.open() as f:
        authors = json.load(f)
    for a in authors:
        assert len(authors[a]['City']) > 0


# data1 = {
#     'Ned': {'City': 'Boston'},
#     'Brian': {'City': 'Portland'},
#     'Luciano': {'City': 'Sau Paulo'}
# }
#
# with open('data.json', 'w') as f:
#     json.dump(data1, f)
#
# # # 读取数据
# with open('data.json', 'r') as f:
#     data = json.load(f)
#     print(data)
#     for a in data:
#         print(a)
#         print(len(data[a]['City']))

