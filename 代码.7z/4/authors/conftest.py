import json
import pytest


@pytest.fixture(scope='module')
def author_file_json(tmpdir_factory):
    python_author_data = {
        'Ned': {'City': 'Boston'},
        'Brian': {'City': 'Portland'},
        'Luciano': {'City': 'Sau Paulo'}
    }

    file = tmpdir_factory.mktemp('data').join('author_file.json')
    print('file:{}'.format(str(file)))

    with file.open('w') as f:
        json.dump(python_author_data, f)
    return file

# json.dumps：将Python对象编码成JSON字符串
# json.dump：将Python文件编码成JSON文件
# json.loads：将已编码的JSON字符串解码为Python对象
# json.loads：将已编码的JSON文件解码为Python文件
