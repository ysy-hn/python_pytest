# import pytest
# import warnings
#
#
# def lame_function():
#     warnings.warn('请停止使用', DeprecationWarning)
#
#
# def test_lame_function(recwarn):
#     lame_function()
#     recwarn.clear()
#     assert len(recwarn) == 1
#     w = recwarn.pop()
#     assert w.category == DeprecationWarning
#     assert str(w.message) == '请停止使用'
#
#
# def test_lame_function_2():
#     with pytest.warns(None) as warning_list:
#         lame_function()
#
#     assert len(warning_list) == 1
#     w = warning_list.pop()
#     assert w.category == DeprecationWarning
#     assert str(w.message) == '请停止使用'


import warnings
import pytest


def lame_function():
    warnings.warn('请停止使用这个函数', DeprecationWarning)


def test_lame_function(recwarn):
    lame_function()
    assert len(recwarn) == 1
    w = recwarn.pop()
    assert w.category == DeprecationWarning
    assert str(w.message) == '请停止使用这个函数'
    assert w.filename[-2:] == 'py'
    assert w.lineno == 1

