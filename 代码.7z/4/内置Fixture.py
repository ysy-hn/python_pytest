# # ！/usr/bin/python3
# -*- coding: utf-8 -*-
# 当前项目名称：python_基础教程
# 文件名称： 内置Fixture
# 登录用户名： yanshaoyou
# 作者： 闫少友
# 邮件： 2395969839@qq.com
# 电话：17855503800
# 创建时间： 2021/10/12  9:43

# tmpdir、tmpdir_factory（函数、会话创建临时文件目录，测试后删除）
# tmpdir和tmpdir_factory负责在测试开始运行前创建临时文件目录，并在测试结束后删除。
# tmpdir 的作用范围是函数级别，tmpdir_factory 的作用范围是会话级别。
#
# pytestconfig（配置对象，控制pytest）
#
# cache（缓存） 的作用是存储一段测试会话的信息，在下一段测试会话中使用。
# 使用 pytest 内置的 --last-failed 和 --failed-first 标识可以很好的展示 cache的功能。
# 如果要清空缓存，可以在测试会话开始前传入 --cache-clear
# duration_cache 的作用范围是会话级别的。在所有测试用例运行之前，它会读取之前的 cache 记录。
#
# capsys（临时禁止抓取日志输出），使用readouterr读取
# pytest 内置的 capsys 有两个功能：允许使用代码读取 stdout 和 strerr；可以临时禁止抓取日志输出。
#
# monkey patch（动态修改）
# monkey patch 可以在运行期间对类或模块进行动态修改，在测试中，monkey patch 常用于替换被测试代码的部分运行环境，
# 或者将输入依赖或输出依赖替换成更容易测试的对象或函数。
#
# doctest_namespace（示例代码文档，命名空间）
# doctest 模块是 Python 标准库的一部分，借助它，可以在函数的文档字符串中放入示例代码，并通过测试确保有效。
# 你可以使用 --doctest-modules 标识搜寻并运行 doctest 测试用例
#
# recwarn（检查待测代码产生的警告信息）
# 内置的 recwarn 可以用来检查待测代码产生的警告信息。在Python 里，可以添加警告信息，它们很像断言，但是并不阻止程序运行。

