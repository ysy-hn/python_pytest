import pytest


def pytest_addoption(parser):
    """Turn nice features on with --nice option."""
    group = parser.getgroup('nice')
    group.addoption("--nice", action="store_true",
                    help="nice: 失败是改进的机会")


def pytest_report_header(config):
    """Thank tester for running tests."""
    if config.getoption('nice'):
        return "欢迎您，使用运行这些测试."


def pytest_report_teststatus(report, config):
    """Turn failures into opportunities."""
    if report.when == 'call':
        if report.failed and config.getoption('nice'):
            return (report.outcome, 'O', '改进的机会')

