from collections import namedtuple

task = namedtuple('yan', ['名称', '性别', '年龄', '职业'])

def test_1():
    t = task('闫少友', '男', 25, '测试')
    assert t.名称 == '闫少友'
    assert t.性别 == '男'
    assert t.年龄 == 25
    assert t.职业 == '测试'


def test_2():
    assert 1 in [1, 2, 3, 4]


def test_3():
    a = 1
    b = 2
    assert a < b


def test_4():
    assert 'fizz' in 'fizzbuzz'