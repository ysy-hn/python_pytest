# # ！/usr/bin/python3
# -*- coding: utf-8 -*-
# 当前项目名称：python_基础教程
# 文件名称： pytest入门
# 登录用户名： yanshaoyou
# 作者： 闫少友
# 邮件： 2395969839@qq.com
# 电话：17855503800
# 创建时间： 2021/10/12  9:42


# 建立虚拟环境,先创建一个项目文件，再创建python -m venv ll_env(项目虚拟环境名称）;
# 激活虚拟环境,ll_env\Scripts\activate;
# deactivate:停止虚拟环境。

# ::test_name     运行指定单个用例
# --collect-only  展示要运行那些用例
# -k              关键字指定运行的用例
# -m              标记用例，分组运行
# -x              断言失败时停止运行
# --tb=no         关闭错误信息回溯
# --tb=line       打印异常代码位置
# --tb=short      仅输出assert的一行和系统判定内容（不显示上下文）
# --tb=long       输出详尽的信息
# --tb=auto       默认值，有多个失败，打印第一个和最后一个
# --tb=native     只输出python标准库的回溯信息
# --maxfail=num   允许失败几次停止运行

# --lf（last failed）    仅运行上次失败的测试用例，不运行剩下的用例
# --ff（failed first）   先定位并运行上次第一个失败的用例，再运行剩下的用例
# -v/--verbose    详情
# -q              简化输出
# -l              失败时，打印局部变量和值
# --durations=N     显示最慢的N个阶段，N=0时，从长到短排序
# --version         显示当前pytest版本及安装目录
# -h                显示用法和新添加的插件的选项和用法
# -s（--capture=no） 关闭输出捕获
