# # ！/usr/bin/python3
# -*- coding: utf-8 -*-
# 当前项目名称：python_基础教程
# 文件名称： test_three
# 登录用户名： yanshaoyou
# 作者： 闫少友
# 邮件： 2395969839@qq.com
# 电话：17855503800
# 创建时间： 2021/10/14  16:22


from collections import namedtuple
import pytest

Task = namedtuple('Task', ['summary', 'owner', 'done', 'id'])
Task.__new__.__defaults__ = (None, None, False, None)


def test_defaults():
    t1 = Task()
    t2 = Task(None, None, False, None)
    assert t1 == t2


@pytest.mark.run_these_please
def test_member_access():
    t = Task('buy milk', 'brian')
    assert t.summary == 'buy milk'
    assert t.owner == 'brian'
    assert (t.done, t.id) == (False, None)



# from collections import namedtuple
#
#
# Task = namedtuple('Task',['summary', 'owner', 'done', 'id'])
# Task.__new__.__defaults__ = (None, None, False, None)
#
# def test_defaults():
#     """验证默认值"""
#     t1 = Task()
#     t2 = Task(None, None, False, None)
#     assert t1 == t2
#
#
# def test_member_access():
#     """验证访问对象"""
#     t = Task('buy milk', 'brian')
#     assert t.summary == 'buy milk'
#     assert t.owner == 'brian'
#     assert (t.done, t.id) == (False, None)

