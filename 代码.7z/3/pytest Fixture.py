# # ！/usr/bin/python3
# -*- coding: utf-8 -*-
# 当前项目名称：python_基础教程
# 文件名称： pytest Fixture
# 登录用户名： yanshaoyou
# 作者： 闫少友
# 邮件： 2395969839@qq.com
# 电话：17855503800
# 创建时间： 2021/10/12  9:43

# fixture 是在测试函数运行前后，由pytest执行的外壳函数。

# 3.1 fixture 可以放在单独的测试文件里。此时只有这个测试文件能够使用相关的fixture。
# 如果希望多个测试文件共享 fixture，可以在某个公共目录下新建一个 conftest.py 文件，
# 将 fixture 放在其中。（作用域根据所放的文件夹决定，最上层文件夹的话整个项目共用，子文件夹的话，子文件夹里面的测试共用。）
# 尽管 conftest.py 是Python 模块，但它不能被测试文件导入。
# import conftest 的用法是不允许出现的。conftest.py 被 pytest 视作一个本地插件库。
# 可以把 tests/conftest.py 看成一是一个供 tests 目录下所有测试使用的 fixture仓库。

# 3.2 fixture 函数会在测试函数之前运行，但如果 fixture 函数包含 yield，那么系统会在 yield 处停止，
# 转而运行测试函数，等测试函数执行完毕后再回到 fixture，继续执行 yield 之后的代码。
# 可以将 yield 之前的代码视为 配置（setup）过程，将yield 之后的代码视为清理（teardown）过程。
# 无论测试过程中发生了说明，yield之后的代码都会被执行。

# 3.3 使用--setup-show 回溯fixture的执行过程
# fixture 名称前面的F 和S代表的是fixture的作用范围，F代表函数级别的作用范围。S代表会话级别的作用范围。

# 3.4 使用fixture传递测试数据
# fixture 非常适合存放测试数据，并且它可以返回任何数据。
# 使用fixture传递测试数据，如果测试结构执行结果是ERROR而不是FAIL。error是被测试的函数异常，fail是测试函数异常。

# 3.5 使用多个fixture
# fixture相互调用；
# 用例中传入多个fixture

# 3.6 指定fixture作用范围
# fixture包含一个叫scope（作用范围）的可选参数，控制fixture 执行配置和销毁逻辑的频率。scope 参数有四个待选值：
# function：默认；函数级别；每个测试函数只需要运行一次。配置代码在测试用例运行之前运行，销毁代码在测试用例运行之后运行。
# class：类级别的fixture 每个测试类只需要运行一次，无论测试类里面有多少类方法都可以共享这个fixture。
# module：模块级别的fixture每个模块只需要运行一次，无论模块里有多少个测试函数、类方法或其他fixture 都可以共享这个fixture.
# session（默认值）:会话级别的 fixture 每次会话只需要运行一次。一次 pytest 会话中所有测试函数、方法都可以共享这个 fixture。
# F代表函数级别，S代表会话级别，C代表类级别，M代表模块级别;fixture只能使用同级别的fixture，或比自己级别更高的fixture。

# 3.7 使用usefixtures指定fixture
# 使用usefixtures和在测试方法中添加fixture参数，二者大体上是差不多的。区别之一在于只有后者才能够使用fixture的返回值。

# 3.8 为常用fixture添加autouse选项
# 之前用到的 fixture 都是根据测试本身来命名的（或者针对示例的测试类使用 usefixtures）。
# 我们可以通过制定 autouse=True选项，使作用域内的测试函数都自动运行 fixture

# 3.9 为fixture重命名
# @pytest.fixture(name="another")

# 3.10 fixture的参数化
# fixture 参数列表中的request 也是 pytest 内建的fixture 之一。代表 fixture 的调用状态。
# 它有一个 param 字段，会被@pytest.fixture(params = tasks_to_try) 的params 列表中的一个元素填充。
# 也可以指定 ids。（只不过这里的 ids 也是函数，不是列表）
