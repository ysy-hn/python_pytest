# 附录A 虚拟环境
# 虚拟环境安装方法
# 建立虚拟环境,先创建一个项目文件，再创建python -m venv ll_env(项目虚拟环境名称）;
# 激活虚拟环境,ll_env\Scripts\activate;
# deactivate:停止虚拟环境。
# 将所有虚拟环境放在一个共同目录，环境名字不同，命令提示符更有意义；也不用担心.gitignore文件，方便查看有哪些项目。
#
#
# 附录B pip
# 不使用虚拟环境时，pip一般安装在site-packages目录中
# pip --version： 查看版本
# pip list： 查看安装的插件
# pip install something: 安装插件
# pip uninstall something: 卸载插件
# pip install ./something: 本地安装插件，在插件目录下，无需解压
# cat requirements.txt: 整合/读取内容；linux命令
# type requirements.txt: 整合/读取内容；windows命令
# pip install -r requirements.txt: 安装requirements.txt文件中的插件版本，也可使用其它文件名，一般是requirements名
#
#
# 附录C 常用插件
# pytest-repeat: 重复运行测试——对多次运行的测试较好
# pip install pytest-repeat: 安装
# pytest --count=n： 运行n次，其它按pytest正常使用
# 更多方法阅读PyPI上的pytest-repeat文档
#
# pytest-xdist: 并行运行测试，可以指定处理器数目同时运行，甚至放在多台机器运行——对数据量大的测试使用较好
# pip install pytest-xdist： 安装
# -n numprocesses选项： 指定运行测试的处理器进程数
# -n auto选项： 自动侦测系统里的CPU数目并使用
# 更多方法阅读PyPI上的pytest-xdist文档
#
# pytest-timeout:为测试设置时间限制——对时间有限制的测试使用较好，如Web服务等
# pip install pytest-timeout: 安装
# pytest --timeout=n： 超时n，其它按pytest正常使用
# 更多方法阅读PyPI上的pytest-timeout文档
#
# pytest-instafail:查看错误的详细信息——时间长且有人监视时使用较好
# pip install pytest-instafail: 安装
# pytest --instafail： 遇到错误时，直接打印相关信息并继续测试
# 更多方法阅读PyPI上的pytest-instafail文档
#
# pytest-sugar：显示色彩和进度条——信息反馈界面友好
# pip install pytest-sugar: 安装，安装后自动默认使用
#
# pytest-emoji：为测试增添乐趣——自定义反馈风格
# pip install pytest-emoji: 安装
# pytest --emoji:使用，具体使用什么风格在hook函数中自定义
# 更多方法阅读PyPI上的pytest-emoji文档
#
# pytest-html:为测试生成HTML报告
# pip install pytest-html: 安装
# pytest --html=report_name.html:使用
# 更多方法阅读PyPI上的pytest-html文档
#
# 静态分析插件
# pytest-pycodestyle: python代码风格检查
# pip install pytest-pycodestyle: 安装
# pytest --pep8:使用
# 更多方法阅读PyPI上的pytest-pycodestyle文档
#
# pytest-selenium： 借助浏览器完成自动化测试
# pytest-django： 测试Django应用
# pytest-flask： 测试Flask应用
#
#
# 附录D 打包和发布Python项目
# 创建可以从pip安装的项目：
# 创建可安装的模块：把模块和setup文件放在同一目录
# 创建可安装的包：把项目和setup放在同一目录，项目中有__init__文件
# 创建源码发布包和Wheel文件：直接安装python setup.py sdist something；有警告
# 消除警告：
# 1、添加README、README.rst或README.txt文件
# 2、补充配置中的url数据
# 3、补充作者、邮箱、版本号、变更记录等基础信息
# 4、软件使用许可
# README文件告诉用户如何使用你的包；
# url、作者、邮箱等告诉用户遇到问题与谁联系；
# 软件使用许可告诉用户使用包的注意事项（分发、贡献、复用代码有哪些限制）
# 如果不希望开源软件使用许可里写清楚；如果开源推荐访问https://choosealicense.com选择合适的软件许可
# LICENSE文件放许可条文
# CHANGELOG.rst文件放变更记录，编写风格可阅读https://keepachngelog.com
